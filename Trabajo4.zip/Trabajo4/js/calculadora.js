function calcular(){
    
    peso=parseFloat(document.getElementById("peso").value)
    altura=parseFloat(document.getElementById("altura").value)

    altura=altura/100
    function obtenerImc(peso,altura){
        if(altura !=0){
            return peso/(altura*altura);
        }else{
            return  "No se puede calcular el IMC";
        }
    }

    function obtenerEstado(imc){ 
        if(imc <= 15){
            return "Delgadez muy severa";
        } else if( imc > 15 && imc < 15.9 ){
            return "Delgadez severa";
        } else if( imc >= 16 && imc <= 18.4 ){
            return "Delgadez";
        } else if( imc > 18.5 && imc < 24.9 ){
            return "Normal o Saludable";
        } else if( imc > 25 && imc < 29.9 ){
            return "Sobrepeso";
        } else if( imc > 30 && imc < 34.9 ){
            return "Obesidad moderada";
        } else if( imc > 35 && imc < 39.9 ){
            return "Obesidad severa";
        } else if( imc >= 40 ){
            return "Obesidad mórbida";
        }
   }  

    imc=obtenerImc(peso,altura);
    estado=obtenerEstado(imc)
    document.getElementById("resultado").innerText=imc.toFixed(2)+"\n"+estado
}